let div = document.querySelector('#block');

function colors() {
    setTimeout(() => ((div.classList.remove("black")),(div.classList.add("green"))), 2000);
    setTimeout(() => ((div.classList.remove("green")),(div.classList.add("red"))), 5000);
    setTimeout(() => ((div.classList.remove("red")),(div.classList.add("black"))), 10000);
}

div.addEventListener("click",() => (setInterval(colors, 1000)))

