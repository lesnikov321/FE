// вывести возраст остальных обьектов используя метод showAge позаимствованый у обьекта person

person.showAge();
person.showAge.call(person2);
person.showAge.call(person3);
person.showAge.call(person4);
person.showAge.call(person5);
