//3. Определить среднее арифметическое трех чисел.
const userscount1 = parseInt(prompt("Введите первое число:"));
const userscount2 = parseInt(prompt("Введите второе число:"));
const userscount3 = parseInt(prompt("Введите третье число:"));
const result3 = (userscount1 + userscount2 + userscount3) / 3;
alert(result3);