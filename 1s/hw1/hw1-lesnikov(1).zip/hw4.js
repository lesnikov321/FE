// 4. (*) Разложить по цифрам пятизначное число и вывести в исходном порядке через пробел используя template string
const usersDigit = prompt("Введите пятизначное число:");
const firstDigit = (usersDigit - (usersDigit%10000))/10000;
const secondDigit = ((usersDigit%10000)-(usersDigit%1000))/1000;
const thirdDigit = ((usersDigit%1000)-(usersDigit%100))/100;
const fourthDigit = ((usersDigit%100)-(usersDigit%10))/10;
const fifthDigit = ((usersDigit%10)-(usersDigit%1));
const result4 = `Вы ввели число ${usersDigit} следующей последовательности цифр: ${firstDigit}, ${secondDigit}, ${thirdDigit}, ${fourthDigit}, ${fifthDigit}.`;
alert(result4);