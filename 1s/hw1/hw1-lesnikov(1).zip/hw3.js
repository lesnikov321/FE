//3. Определить среднее арифметическое трех чисел.
const count1 = parseInt(prompt("Введите первое число:"));
const count2 = parseInt(prompt("Введите второе число:"));
const count3 = parseInt(prompt("Введите третье число:"));
const result3 = (count1 + count2 + count3) / 3;
alert(result3);