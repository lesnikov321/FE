// Дана базовая структура (hml + css). 
// Написать функционал таймера, который будет стартовать при открытии страницы и выводить в подготовленный элемент 
// (div с классом main) количество секунд проведенноё на сайте. Значение меняетя раз в сенкунду. 
// Функционал должен быть написан в отдельном js файле. html, css файлы можно изменять.

// **.. добавить 2 кнопки start/stop - по клику на которые секундомер будет начинать отсчёт и останавливать

let count = 0;
let sec = document.querySelector('#main');
let start = document.querySelector('#start');
let stop = document.querySelector('#stop');
  
function counter() {
    sec.innerHTML = count;
    count++
    return count
}

let time = setInterval(() => (counter()), 1000)

start.addEventListener("click",() => {time})
stop.addEventListener("click",() => {clearInterval(time)})