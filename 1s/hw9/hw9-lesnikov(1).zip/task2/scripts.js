let header = document.getElementsByTagName("div");

[].forEach.call(header, function(el) {
    el.addEventListener("click", function (){
        document.body.style.background = `${this.innerText}`;
    })
})